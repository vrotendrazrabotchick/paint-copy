﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            double b = double.Parse(textBox2.Text);

            double epsilon = 0.01;

            double root = BisectionMethod(a, b, epsilon);
            textBox3.Text = root.ToString();
        }

        public double Function(double x)
        {
            return x * x *x- 5 * x*x + 4;
        }

        private double BisectionMethod(double a, double b, double epsilon)
        {
            double fa = Function(a);
            double fb = Function(b);

            if (fa * fb >= 0)
            {
                textBox3.Text = "Корень не найден на заданном интервале.";
                return double.NaN;
            }

            double c;
            while (Math.Abs(b - a) >= epsilon)
            {
                c = (a + b) / 2;
                double fc = Function(c);

                if (fc == 0)
                    break;
                else if (fa * fc < 0)
                    b = c;
                else
                    a = c;
            }

            return (a + b) / 2;
        }
        
          
    }
}
